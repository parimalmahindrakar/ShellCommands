# Html-table-with-custom-filters
Filters for each column seperately for HTML tables using Javascript and Jquery.
