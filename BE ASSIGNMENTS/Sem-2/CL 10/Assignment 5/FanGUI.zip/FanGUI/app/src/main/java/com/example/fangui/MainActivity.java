package com.example.fangui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ImageView fanIV;
    Animation rotation;
    TextView speed;
    int duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fanIV = (ImageView) findViewById(R.id.imageView);
        duration = 1500;
        speed = (TextView) findViewById(R.id.speedtv);
    }

    public void upspeed(View view) {
        if(duration == 1100)
            duration = 1100;
        else
            duration -= 100;
        speed.setText(getSpeed(duration));
        rotation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotate);
        rotation.setFillAfter(true);
        rotation.setDuration(duration);
        fanIV.startAnimation(rotation);
    }

    public void downspeed(View view) {
        if(duration == 1500)
            duration = 1500;
        else
            duration += 100;
        speed.setText(getSpeed(duration));
        rotation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotate);
        rotation.setFillAfter(true);
        rotation.setDuration(duration);
        fanIV.startAnimation(rotation);
    }

    private String getSpeed(int duration){
        switch (duration){
            case 1500:
                return "1";
            case 1400:
                return "2";
            case 1300:
                return "3";
            case 1200:
                return "4";
            case 1100:
                return "5";
            default:
                return "UNK";
        }
    }
}